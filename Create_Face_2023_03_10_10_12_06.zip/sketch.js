function setup() {
  createCanvas(800, 800);
}
function draw(){
  background(255);
  
    //귀 만들기
  //왼쪽 귀
  push();
  fill(25,25,110)
  noStroke();
  triangle(150, 50, 90, 350, 300, 250)
  pop();
  
  push();
  fill(200,200,200)
  noStroke();
  triangle(170, 150, 90, 350, 300, 250)
  pop();
  
  //오른쪽 귀
  push();
  fill(25,25,110)
  noStroke();
  triangle(520, 50, 560, 350, 350, 250)
  pop();
  
  push();
  fill(200,200,200)
  noStroke();
  triangle(500, 150, 560, 350, 350, 250)
  pop();
  
  //얼굴 만들기
  push();
  translate(300, height/2);
  noStroke();
  fill(25,25,110);
  ellipse(25, 30, 500)
  pop();
  
  //눈 만들기
  
  // 첫 번째 호를 그립니다.
  push(); // 현재 상태를 저장합니다.
  translate(200, height/2); // 위치를 설정합니다.
  rotate(radians(30)); // 30도(라디안으로 변환하여) 회전합니다.
  noStroke();
  fill(0,0,0);
  arc(0, 0, 200, 200, 0, PI);
  pop(); // 이전 상태로 돌아갑니다.

  // 두 번째 호를 그립니다.
  push();
  translate(200, height/2);
  rotate(radians(30)); 
  noStroke();
  fill(255,255,0);
  arc(0, 0, 30, 150, 0, PI);
  pop();
  
  //반대편에 좌우반전시켜서 똑같이 그려줍니다.
  
    // 첫 번째 호를 그립니다.
  push(); // 현재 상태를 저장합니다.
  translate(450, height/2); 
  scale(-1, 1); // X축을 기준으로 좌우반전합니다.
  rotate(radians(30)); 
  noStroke();
  fill(0,0,0);
  arc(0, 0, 200, 200, 0, PI);
  pop(); 

  // 두 번째 호를 그립니다.
  push();
  translate(450, height/2);
  scale(-1, 1); // X축을 기준으로 좌우반전합니다.
  rotate(radians(30)); 
  noStroke();
  fill(255,255,0);
  arc(0, 0, 30, 150, 0, PI);
  pop();
  
  //코와 수염
  
  push();
  fill(0,0,0);
  noStroke();
  triangle(300,530,325,550,350,530);
  pop();

  push();
  stroke(200,200,200);
  line(150,550,500,550);
  line(150,500,500,600);
  line(150,600,500,500);
  pop();
  
}
